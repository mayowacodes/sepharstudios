import{l as o,d as r}from"../chunks/DqoD9RWJ.js";export{o as load_css,r as start};
